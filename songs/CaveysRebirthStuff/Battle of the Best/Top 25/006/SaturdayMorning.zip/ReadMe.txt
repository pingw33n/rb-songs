Use ReNovator, PCP or the 808-editor to
replace the standard bassdrum with BD.AIF
and enjoy the song!